<?php

$config['firebase_app_key'] = __DIR__ . '/../config/bishare-48db5-firebase-adminsdk-xx1on-9754f98aac.json';